const fastify = require("fastify")();
const module = require("p4-module.js");

fastify.get("/cit/question", (request, reply) => {
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {a:module.getQuestions()}
        );
});

fastify.get("/cit/answer", (request, reply) => {
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {a:module.getAnswers()}
        );
});

fastify.get("/cit/questionanswer", (request, reply) => {
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {a:module.getQuestionsAnswers()}
        );
});

fastify.get("/cit/question/:number", (request, reply) => {
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {a:module.getQuestion(request.query)}
        );
});

fastify.get("/cit/answer/:number", (request, reply) => {
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {a:module.getAnswer(request.query)}
        );
});

fastify.get("/cit/questionanswer/:number", (request, reply) => {
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {a:module.getQuestionAnswer(request.query)}
        );
});

fastify.get("*", (request, reply) => {
    reply
        .code(404)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {a:"Route not found"}
        );
});

fastify.post("/cit/question", (request, reply) => {
    reply
        .code(201)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {a:module.addQuestionAnswer(request.query)}
        );
});

fastify.put("/cit/question", (request, reply) => {
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {a:module.updateQuestionAnser(request.query)}
        );
});